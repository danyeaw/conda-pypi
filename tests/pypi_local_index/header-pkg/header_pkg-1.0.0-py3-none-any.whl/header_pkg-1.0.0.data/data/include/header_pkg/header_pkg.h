// header_pkg public API
void do_some_stuff(void);
